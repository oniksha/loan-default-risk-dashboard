# Loan Default Risk Dashboard

An interactive Power BI dashboard analyzing loan performance, applicant demographics, and default risk across employment types, credit tiers, and time.

![Power BI](https://img.shields.io/badge/Power%20BI-Dashboard-F2C811?style=for-the-badge&logo=powerbi&logoColor=black)
![DAX](https://img.shields.io/badge/DAX-Analytics-blue?style=for-the-badge)
![Power Query](https://img.shields.io/badge/Power_Query-Data_Cleaning-success?style=for-the-badge)

---

## Project Overview

Lending decisions carry real risk, and that risk isn't distributed evenly — it shifts by employment type, credit score, age, and marital status, and it moves over time. This project takes a raw loan dataset and builds it into a three-page Power BI report that lets a risk or credit analyst see where default risk is concentrated and how it's trending.

The report is built to answer practical questions: which employment segments default more often, how loan amounts and default rates have moved year over year, and which combinations of credit score and demographic factors carry the most exposure.

With this dashboard, users can:

- Track loan volume and default rates across employment types
- Monitor year-over-year changes in loan amount and default counts
- Segment applicants by credit score, age group, and marital status
- Compare loan sizes and income across borrower profiles
- Break down loan purpose and education-level lending patterns

---

## Objectives

- Analyze total loan volume by purpose, age group, and education
- Measure default rate by employment type and by year
- Track year-over-year change in loan amount and default volume
- Segment applicants by credit score bins and understand exposure by tier
- Compare loan amounts and income across age groups and marital status
- Build a report that surfaces risk concentration rather than just raw totals

---

## Tech Stack

- **Microsoft Power BI** — dashboard and reporting layer
- **DAX** — measures and calculated KPIs
- **Power Query** — data cleaning and transformation
- Data modeling and interactive visualization design

---

## Report Pages

### 1. Loan Default & Overview
A high-level read on the loan book: loan amount by purpose, average income by employment type, default rate by employment type, average loan amount by age group, and default rate trend by year.

![Loan Default Overview](loan_default_overview.png)

### 2. Applicant Demographics & Financial Profile
Segments the borrower base in more detail — median loan amount by credit score category, average high-credit loan amount broken down by age group and marital status, total loan amount by credit score bin, mortgage/dependents split for middle-age adults, and loan counts by education level.

![Applicant Demographics & Financial Profile](applicant_demographics.png)

### 3. Financial Risk Metrics
Focuses on trend and exposure: year-over-year loan amount change, year-over-year default change, year-to-date loan amount by credit score bin and marital status, and total loan volume broken out by income bracket and employment type.

![Financial Risk Metrics](financial_risk_metrics.png)

---

## Business Insights

- **Unemployed applicants carry the highest default rate** at roughly 3.4%, compared to around 2.4% for part-time borrowers — a meaningful spread that supports segmenting risk pricing by employment status.
- **Default rate by year has stayed relatively stable**, hovering between 11.5% and 11.75% across the observed period, suggesting the loan book's overall risk profile hasn't shifted dramatically year to year.
- **Loan amount and default counts don't always move together.** Year-over-year loan amount growth has swung both positive and negative across years, while default rate has stayed comparatively flat — worth digging into further if underwriting standards changed over time.
- **High-credit borrowers are fairly evenly distributed across age groups and marital status**, with average loan amounts in the high-credit tier clustering tightly around 124K–128K regardless of segment.
- **Income bracket is a strong lever on total loan volume** — high-income borrowers account for the large majority of total loan volume, far outweighing medium- and low-income segments combined.

---

## Data Preparation

The dataset was cleaned and shaped using Power Query, including:

- Standardizing the loan date field for year-based calculations
- Building segmentation columns for income bracket, credit score bins, and age groups directly in DAX
- Handling missing or blank values in loan ID and demographic fields
- Structuring the model to support year-over-year and year-to-date comparisons

---

## DAX Measures

A sample of the core measures powering the dashboard:

```DAX
Year =
YEAR('Loan_default'[Loan_Date_DD_MM_YYYY].[Date])
```

```DAX
Income Bracket =
SWITCH(
    TRUE(),
    'Loan_default'[Income] < 30000, "Low Income",
    'Loan_default'[Income] >= 30000 && 'Loan_default'[Income] < 60000, "Medium Income",
    'Loan_default'[Income] >= 60000, "High Income"
)
```

```DAX
Credit Score Bins =
IF('Loan_default'[CreditScore] <= 400, "Very Low",
    IF('Loan_default'[CreditScore] <= 450, "Low",
        IF('Loan_default'[CreditScore] <= 650, "Medium", "High")))
```

```DAX
Age Groups =
IF('Loan_default'[Age] <= 19, "Teen",
    IF('Loan_default'[Age] <= 39, "Adults",
        IF('Loan_default'[Age] <= 59, "Middle Age Adults", "Senior Citizens")))
```

```DAX
Default Rate by Employment type =
VAR TotalRecords = COUNTROWS(ALL('Loan_default'))
VAR DefaultCases = COUNTROWS(FILTER('Loan_default', 'Loan_default'[Default] = TRUE()))
RETURN
CALCULATE(DIVIDE(DefaultCases, TotalRecords), ALLEXCEPT('Loan_default', 'Loan_default'[EmploymentType])) * 100
```

```DAX
Default Rate by Year =
VAR TotalLoans =
    CALCULATE(COUNTROWS('Loan_default'), ALLEXCEPT('Loan_default', Loan_default[Year]))
VAR Defaults =
    CALCULATE(COUNTROWS(FILTER('Loan_default', 'Loan_default'[Default] = TRUE())), ALLEXCEPT('Loan_default', Loan_default[Year]))
RETURN
DIVIDE(Defaults, TotalLoans) * 100
```

```DAX
YOY Loan Amount Change =
DIVIDE(
    CALCULATE(SUM('Loan_default'[LoanAmount]), 'Loan_default'[Year] = YEAR(MAX('Loan_default'[Loan_Date_DD_MM_YYYY]))) -
    CALCULATE(SUM('Loan_default'[LoanAmount]), 'Loan_default'[Year] = YEAR(MAX('Loan_default'[Loan_Date_DD_MM_YYYY])) - 1),
    CALCULATE(SUM('Loan_default'[LoanAmount]), 'Loan_default'[Year] = YEAR(MAX('Loan_default'[Loan_Date_DD_MM_YYYY])) - 1), 0
) * 100
```

```DAX
YOY Default Loans Change =
DIVIDE(
    CALCULATE(COUNTROWS(FILTER('Loan_default', 'Loan_default'[Default] = TRUE())), 'Loan_default'[Year] = YEAR(MAX('Loan_default'[Loan_Date_DD_MM_YYYY]))) -
    CALCULATE(COUNTROWS(FILTER('Loan_default', 'Loan_default'[Default] = TRUE())), 'Loan_default'[Year] = YEAR(MAX('Loan_default'[Loan_Date_DD_MM_YYYY])) - 1),
    CALCULATE(COUNTROWS(FILTER('Loan_default', 'Loan_default'[Default] = TRUE())), 'Loan_default'[Year] = YEAR(MAX('Loan_default'[Loan_Date_DD_MM_YYYY])) - 1), 0
) * 100
```

```DAX
YTD Loan Amount =
CALCULATE(
    SUM('Loan_default'[LoanAmount]),
    DATESYTD('Loan_default'[Loan_Date_DD_MM_YYYY].[Date]),
    ALLEXCEPT('Loan_default', Loan_default[Credit Score Bins], Loan_default[MaritalStatus])
)
```

```DAX
Average Loan Amt (High Credit) =
AVERAGEX(FILTER('Loan_default', 'Loan_default'[Credit Score Bins] = "High"), 'Loan_default'[LoanAmount])
```

---

## Dashboard Features

- Multi-page report covering overview, applicant demographics, and risk trend
- Segmentation logic (income bracket, credit score bins, age groups) built entirely in DAX
- Year-over-year and year-to-date time intelligence
- Interactive filtering across employment type, credit tier, and demographic fields
- Clean, consistent visual theme across all three pages

---

## Repository Structure

```
Loan-Default-Dashboard
│
├── Dashboard.pbix
├── Dataset.xlsx
├── README.md
├── images/
│   ├── loan_default_overview.png
│   ├── applicant_demographics.png
│   └── financial_risk_metrics.png
└── Loan_Default.pdf
```

---

## Skills Demonstrated

Data cleaning · Data transformation · Data modeling · DAX (SWITCH, ALLEXCEPT, time intelligence) · Risk segmentation · Business intelligence · Dashboard design · Data visualization · Analytical thinking

---

## Future Improvements

- Predictive default risk scoring using historical trends
- Row-Level Security (RLS) by employment type or region
- Drill-through pages for individual applicant records
- Deployment to Power BI Service with scheduled refresh
- Mobile-optimized layout

---

## Author

**Nikhil Dagar**
Data Analyst · Power BI Developer · Business Intelligence Enthusiast


---

If you found this project useful, a star on the repo is always appreciated.
